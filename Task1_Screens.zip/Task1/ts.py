#Cell class to store a state's 
#possible movements, distance to another point
class Cell:  
    def __init__(self,x,y):
        self.x = x
        self.y = y
    def right(self):
        return Cell(self.x,self.y+1)
    def left(self):
        return Cell(self.x,self.y-1)
    def up(self):
        return Cell(self.x-1,self.y)
    def down(self):
        return Cell(self.x+1,self.y)
    def distance(self,other):
        return math.sqrt(((other.x-self.x)**2)+((other.y-self.y)**2))
    def isEqual(self,other):
        return self.x==other.x and self.y==other.y
    
class Model:
    def __init__(self,grid_width,grid_height):
        #grid_width and grid_height specify the simulation environement 
        self.grid_width = grid_width
        self.grid_height = grid_height
        self.empty = " "
        self.ped = "P"
        self.obs = "O"
        self.tar = "T"
        #obstacles in the simulation
        self.obstacles = []
        #pedestrians in the simulation
        self.pedestrians = [Cell(4,24)]
        # Boolean array to check 
        # if a pedestrian reached the target 
        self.reachedPedestrians = [False for i in range(len(self.pedestrians))]
        #targets in the simulation
        self.targets = [Cell(24,24)]
        
        self.grid = self.createGrid()
        self.placeStates()
    #Creates initial simulation with empty cells
    def createGrid(self):
        return [ [self.empty]*self.grid_width for i in range(self.grid_height)]
    #Places pedestrians,obstacles and targets in the grid
    def placeStates(self):
        for p in self.pedestrians:
            self.grid[p.x][p.y] = self.ped
        for p in self.obstacles:
            self.grid[p.x][p.y] = self.obs
        for p in self.targets:
            self.grid[p.x][p.y] = self.tar
    #Method checks if all pedestrians reach a target.
    def allFinished(self):
        for p in self.finishedPedestrians:
            if not p:
                return False
        return True
    
    #Updates grid based on the movement of current pedestrian
    def update(self,p,shortestCell,i,finished):
        self.grid[p.x][p.y] = self.empty
        self.grid[shortestCell.x][shortestCell.y] = self.ped
        self.pedestrians[i].x = shortestCell.x
        self.pedestrians[i].y = shortestCell.y
        if finished:
            self.finishedPedestrians[i] = True

    #Simulates each pedestrian one step 
    # according to shortest distance move
    def simulateOneStep(self):
        for i in range(len(self.pedestrians)):
            if not self.finishedPedestrians[i]:
                p = self.pedestrians[i]
                shortestCell,finished = self.findShortestMove(p)
                self.update(p,shortestCell,i,finished)
    #Checks if a cell is in the grid and movable and empty       
    def isValidCell(self,p):
        return p.x>=0 and p.x<self.grid_height and p.y>=0 and p.y<self.grid_width and self.grid[p.x][p.y] == self.empty
    # Finds shortest distance 1 step move
    # returns cell with shortest distance to the current pedestrian
    # returns reached: True if the current pedestrian reached the target
    def findShortestMove(self,p):
        currentDistance =p.distance(self.targets[0])
        shortestCell = p
        for target in self.targets:
            if self.isValidCell(p.left()) and p.left().distance(target) < currentDistance:
                currentDistance = p.left().distance(target)
                shortestCell = p.left()
            if self.isValidCell(p.right()) and p.right().distance(target) < currentDistance:
                currentDistance = p.right().distance(target)
                shortestCell = p.right()
            if self.isValidCell(p.up()) and p.up().distance(target) < currentDistance:
                currentDistance = p.up().distance(target)
                shortestCell = p.up()
            if self.isValidCell(p.down()) and p.down().distance(target) < currentDistance:
                currentDistance = p.down().distance(target)
                shortestCell = p.down()
        # If pedestrian reaches target distance between
        # target and pedestrian should be 1
        if currentDistance == 1:
            finished = True
        else:
            finished = False
        return shortestCell,finished
    

